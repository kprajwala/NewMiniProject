<?php
    session_start();
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	?>
<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}

.main {
  margin-left: 510px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  margin-top:150px;
  width: 600px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								
								<li><a href="admin.php">NGO Records</a></li>
								<li><a href="admin.php">Donor Records</a></li>
								<li><a href="sendMails.php">Send emails</a></li>
								<li><a href="admin_login.php">LogOut</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	

	<div class="main"><center>
	<form method="post" action="n_goods_validate.php"><center>
	<h2><font color="#CD5C5C"><u>GOODS SEARCH</u></font></h2><br>
		<h3><b>Enter item name : 
		<input type="text" name="item" style="padding:6px 6px 6px 6px; text-color:#ffffff; background:#D0D0D0"/><br><br>
		<input type="submit" name="search" value="Search" style="padding:6px 6px 6px 6px; background:#CD5C5C; color:#ffffff"/></h2>
	</form>
	</center>
	</div>
	</body>
</html>
