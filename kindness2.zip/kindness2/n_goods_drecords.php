<?php
session_start();
$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
?>
<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.main {
  margin-left: 150px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
 table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="n_goods_search.php">Search Items</a></li>
								<li><a href="n_goods_drecords.php">Goods Donation</a></li>
								<li><a href="ngo_profile.php">Profile</a></li>
								<li><a href="ngo_login.php">Log Out</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	

	<div class="main">
    <table><br><br>
        <h2><font color="#CD5C5C"><u>DONATION RECORDS</u></font></h2><br>
        <?php
        $sq=$_COOKIE['username'];
		setcookie("username",$sq);
		//$id=$_COOKIE["id"];
		//setcookie("id",$id);
        $arr=mysqli_query($conn,"SELECT id from ngo_login where name='$sq';");
        $row = mysqli_fetch_assoc($arr);
        $id=$row['id'];
        $q="SELECT * FROM `donor_user` INNER JOIN ngo_donations ON donor_user.id = ngo_donations.donor_id where ngo_donations.ngo_id='$id';";
        $result = $conn->query($q);
        
			if ($result->num_rows > 0) {
                $sno=1;
                echo "<tr><td>S.NO</td><td>DONOR NAME</td><td>EMAIL</td><td>CITY</td><td>PHONE NO</td><td>ITEMS</td></tr>";
				while($row = $result->fetch_assoc()) {
                    echo "<tr><td>".$sno."</td><td>".$row["d_name"]."</td><td>".$row["d_email"]."</td><td>".$row["d_city"]."</td><td>".$row["d_phone_no"]."</td><td>".$row["items"]."</td></tr>"; 
                  
                        $sno++;
						
            } 
            echo "</table><br><br>";
			}
			else
			{
				echo "<tr><td><center>No Goods available</td></tr>";
			}
		
	?>
	<table><br><br>
        <h2><font color="#CD5C5C"><u>CASH RECORDS</u></font></h2><br>
		<?php
		$arr=mysqli_query($conn,"SELECT id from ngo_login where name='$sq';");
        $row = mysqli_fetch_assoc($arr);
        $id=$row['id'];
        $q="SELECT * FROM `donor_user` INNER JOIN cash_records ON donor_user.d_email = cash_records.d_email where cash_records.ngo='$sq';";
        $result = $conn->query($q);
        
			if ($result->num_rows > 0) {
                $sno=1;
                echo "<tr><td>S.NO</td><td>DONOR NAME</td><td>EMAIL</td><td>CITY</td><td>PHONE NO</td><td>ITEMS</td></tr>";
				while($row = $result->fetch_assoc()) {
                    echo "<tr><td>".$sno."</td><td>".$row["d_name"]."</td><td>".$row["d_email"]."</td><td>".$row["d_city"]."</td><td>".$row["d_phone_no"]."</td><td>".$row["cash"]."</td></tr>"; 
                  
                        $sno++;
						
            } 
            echo "</table><br><br>";
			}
			else
			{
				echo "<tr><td><center>No Goods available</td></tr>";
			}
        ?>
	
	</div>	
</body>
</html>