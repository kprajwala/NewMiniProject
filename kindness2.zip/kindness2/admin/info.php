<?php
  //$connect=mysql_connect("localhost","root","");
  //$db=mysql_select_db("wt",$connect);
  if(isset($_REQUEST["gp"]))
  {
    $a=$_REQUEST["gp"];
    if($a=="NGO")
    {
       echo "ngo db";
    }
    else
    {
       echo "donar db";
    }
  }
  else
  {
     echo "select an option";
  }
?> 