<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.sidenav {
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 150px;
  left: 10px;
  background: #c0c0c0;
  overflow-x: hidden;
  padding: 8px 0;
}
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #FF1493;
  display: block;
  font-family: 'Acme', sans-serif;
}
.sidenav a:hover {
  color: #2196f3;
}
.main {
   margin-left: 100px; /* Same width as the sidebar + left position in px */
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 20px 300px 0px 100px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
  .submit{
	  background:#CD5C5C;
	  color:white;
  }
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="d_cash.php">Cash Donation</a></li>
								<li><a href="d_goods_donation.php">Goods Donation</a></li>
								<li><a href="d_ngosearch.php">NGO Search</a></li>
								<li><a href="d_profile.php">Profile</a></li>
								<li><a href="donor-login.php">Log Out</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		$id=$_COOKIE["id"];
		setcookie("id",$id);
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		 
	?>
	
	<br><br><br>
	<div class="main"><br><br>
		<form method="post" action="d_goods_donation_v.php"><center>
	<h2><font color="#CD5C5C"><u>SELECT MODE OF  DONATION..</u></font></h2><br>
		<h3>Goods You want to donate....<input type="text" style="background:#D0D0D0" name="goods" required/><br><br>
		<input type="radio" name="mode" value="spec_ngo"/>  Donate to specific NGO<br><br>
		<input type="radio" name="mode" value="mode"/>  Match the requirement<br><br></h3>
		<input type="submit" name="submit" class="submit" value="Submit" style="padding:6px 6px 6px 6px; text-color:#ffffff"/></h2>
	</form>
	</div>
	
</body>
</html>