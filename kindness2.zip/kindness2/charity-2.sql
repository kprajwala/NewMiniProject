-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 21, 2019 at 02:22 PM
-- Server version: 5.7.20
-- PHP Version: 7.1.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `charity`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin`, `pwd`) VALUES
('charity', 'charity');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`name`, `email`, `pwd`, `address`, `contact`) VALUES
('dkjfhg', 'sndhfg@gmail.com', 'sdhf', 'sdjnhb', 2147483647),
('prajwala', 'nikalpurprajwala@gmail.com', 'prajwala', 'bank colony , hyderabad', 2147483647),
('pil', 'sony655@gmail.com', 'iop', 'yuio', 2147483647),
('wdjkfe', 'jdf@gmail.com', 'fgh', 'wert', 987654321),
('shriya', 'shriya@gmail.com', 'shriya', 'hitech city', 2147483647),
('ramya', 'ramya@gmail.com', 'ramya', 'hyd', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `donor_donations`
--

CREATE TABLE `donor_donations` (
  `donation_id` int(255) NOT NULL,
  `donor_id` int(255) NOT NULL,
  `items` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_donations`
--

INSERT INTO `donor_donations` (`donation_id`, `donor_id`, `items`) VALUES
(1, 1, 'shoes'),
(2, 2, 'shoes'),
(3, 1, 'clothes');

-- --------------------------------------------------------

--
-- Table structure for table `donor_user`
--

CREATE TABLE `donor_user` (
  `id` int(255) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `d_email` varchar(50) NOT NULL,
  `d_city` varchar(50) NOT NULL,
  `d_state` varchar(50) NOT NULL,
  `d_phone_no` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_user`
--

INSERT INTO `donor_user` (`id`, `d_name`, `d_email`, `d_city`, `d_state`, `d_phone_no`) VALUES
(1, 'Akash Rama', 'akash@gmail.com', 'Hyderabad', 'Telangana', 738378992),
(2, 'Satya Rama', 'satya@gmail.com', 'Warangal', 'Telangana', 737827379);

-- --------------------------------------------------------

--
-- Table structure for table `d_donation`
--

CREATE TABLE `d_donation` (
  `email` varchar(30) NOT NULL,
  `ngo` varchar(40) NOT NULL,
  `cash` int(10) NOT NULL,
  `items` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `d_donation`
--

INSERT INTO `d_donation` (`email`, `ngo`, `cash`, `items`) VALUES
('nikalpurprajwala@gmail.com', 'Aadarsh Welfare Society', 10000, 'clothes');

-- --------------------------------------------------------

--
-- Table structure for table `ngo`
--

CREATE TABLE `ngo` (
  `ngo` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `area` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pin` int(6) NOT NULL,
  `state` varchar(20) NOT NULL,
  `req` varchar(100) NOT NULL,
  `map` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo`
--

INSERT INTO `ngo` (`ngo`, `address`, `area`, `city`, `pin`, `state`, `req`, `map`) VALUES
('Aadarsh Welfare Society', '1-5-155/B, New Maruthi Nagar', 'Kothapet', 'Hyderabad', 500060, 'Telangana', '', ''),
('Abhaya Foundation', '6-3-609/140/1, Anand Nagar Colony', 'Khairathabad', 'Hyderabad', 500004, 'Telangana', 'clothes', ''),
('Yatna NGO', 'Plot No.22, Road No.2, Park View Enclave, Jubilee ', 'Rao & Raju Colony, B', 'Hyderabad', 500045, ' Telangana ', '', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30454.999500880615!2d78.38864752508019!3d17.417788435852813!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb972b3819db73%3A0xa52c8a9c201a4e89!2sYatna+NGO!5e0!3m2!1sen!2sin!4v1563354530252!5m2!1sen!2sin');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_donations_record`
--

CREATE TABLE `ngo_donations_record` (
  `donation_id` int(255) NOT NULL,
  `ngo_id` int(255) NOT NULL,
  `donor_id` int(255) NOT NULL,
  `items` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_donations_record`
--

INSERT INTO `ngo_donations_record` (`donation_id`, `ngo_id`, `donor_id`, `items`) VALUES
(1, 1, 1, 'shoes'),
(2, 2, 2, 'shoes');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_login`
--

CREATE TABLE `ngo_login` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_no` int(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_login`
--

INSERT INTO `ngo_login` (`id`, `name`, `email`, `phone_no`, `city`, `state`, `address`, `pwd`) VALUES
(1, 'Rama Foundations', 'rmf@gmail.com', 687687879, 'hyderabad', 'telangana', 'Banjara Hills, Santosh Nagar.', '12345'),
(2, 'Racha\'s Foundation', 'racha@gmail.com', 998745656, 'Hyderabad', 'Telangana', 'kbwkjen', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donor_donations`
--
ALTER TABLE `donor_donations`
  ADD PRIMARY KEY (`donation_id`),
  ADD KEY `donor_id` (`donor_id`);

--
-- Indexes for table `donor_user`
--
ALTER TABLE `donor_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ngo_donations_record`
--
ALTER TABLE `ngo_donations_record`
  ADD PRIMARY KEY (`donation_id`),
  ADD KEY `ngo_id` (`ngo_id`),
  ADD KEY `donor_id` (`donor_id`);

--
-- Indexes for table `ngo_login`
--
ALTER TABLE `ngo_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donor_donations`
--
ALTER TABLE `donor_donations`
  MODIFY `donation_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donor_user`
--
ALTER TABLE `donor_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ngo_donations_record`
--
ALTER TABLE `ngo_donations_record`
  MODIFY `donation_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ngo_login`
--
ALTER TABLE `ngo_login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donor_donations`
--
ALTER TABLE `donor_donations`
  ADD CONSTRAINT `donor_donations_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donor_user` (`id`);

--
-- Constraints for table `ngo_donations_record`
--
ALTER TABLE `ngo_donations_record`
  ADD CONSTRAINT `ngo_donations_record_ibfk_1` FOREIGN KEY (`ngo_id`) REFERENCES `ngo_login` (`id`),
  ADD CONSTRAINT `ngo_donations_record_ibfk_2` FOREIGN KEY (`donor_id`) REFERENCES `donor_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
