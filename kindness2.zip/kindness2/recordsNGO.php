<?php
    session_start();
	?>
<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}

.main {
  margin-left: 510px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  margin-top:150px;
  width: 600px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								
								<li><a href="recordsNGO.php">NGO Records</a></li>
								<li><a href="recordsDonor.php">Donor Records</a></li>
								<li><a href="sendMails.php">Send emails</a></li>
								<li><a href="feedback.php">Feedback</a></li>
								<li><a href="admin_login.php">LogOut</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	

	<div class="main"><center>
	<form method="post" action="aNgoV.php"><center>
	<h2><font color="#CD5C5C"><u>Details of NGO..</u></font></h2><br>
		<h3>NGO name....<input type="text" style="background:#D0D0D0" name="ngo" required/><br><br>
		<input type="submit" name="submit" class="submit" value="Submit" style="background:#CD5C5C padding:6px 6px 6px 6px; text-color:#ffffff"/></h2>
	</form>
	</center>
	</div>
	</body>
</html>
