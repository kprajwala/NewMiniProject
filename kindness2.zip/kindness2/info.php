<html>
<head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 2px solid #FFFFFF;}

input[type=text], input[type=password] {
  width: 40%;
  padding: 10px 10px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #008080;
  color: white;
  padding: 10px 10px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 20%;
}

button:hover {
  opacity: 0.8;
}
.container {
  padding: 16px;
}
.header {
  background-color: #e6f2ff;
  padding: 20px;
  text-align: center; 
}
table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
 </style>
</head>
<body>
<center>
<div class="header">
  <h1><font color="black">O</font><font color=#009999>nline Charity</font></h1>
</div>
</body>
<?php
  	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");

  if(isset($_REQUEST["gp"]))
  {
    $a=$_REQUEST["gp"];
    if($a=="NGO")
    {
       echo "<h2><font color='#CD5C5C'><u>All NGO  Details..</u></font></h2><br>";
	   
	   
    }
    else
    {
       echo "donar db";
    }
  }
  else
  {
     echo "select an option";
  }
?> 