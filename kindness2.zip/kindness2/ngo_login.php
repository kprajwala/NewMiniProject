<?php
session_start();
?>

<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	
	<title>Registration Form</title>
        <link rel="stylesheet" href="assets/css/Main.css">
        <script src="assets/js/jquery-1.10.2.min.js"></script>
        <script src="assets/js/JQUERY%20Main.js"></script>
		<style>
			body{
			background-image: url("stars.jpg");
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center;
			position: relative;
			overflow-y: hidden;
			}
			#back{
				text-color : black;
			}
		</style>
</head>
<body>
	<header>
	<div id="search-bar">
			<div class="container">
				<div class="row">
					<form action="#" name="search" class="col-xs-12">
						<input type="text" name="search" placeholder="Type and Hit Enter"><i id="search-close" class="fa fa-close"></i>
					</form>
				</div>
			</div>
		</div>
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
							
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
							<li>
								<a href="#">Admin</a>
							</li>
	

							<li>
								<a href="donor-login.php">Donor</a>
							</li>
							<li>
								<a href="ngo_login.php">NGO</a>
							</li>
						</ul>
					</div>
					
				</div>
			</div>	
		</nav>
	</header>
	<form method="post" action="validation.php">
        <div id="box">
            <div id="main"></div>
            <div id="loginform">
                <h1>NGO LOGIN</h1>
				<?php
				
				if(isset($_SESSION['pass']) && $_SESSION['pass']=="true")
				{
					echo "Invalid password";
					$_SESSION['pass']="false";
				}
				if(isset($_SESSION['no_user']) && $_SESSION['no_user']=="true")
				{
					echo "No user available..";
					$_SESSION['no_user']="false";
				}
				
				?>
                <input type="email" placeholder="Email" name="email"/><br>
                <input type="password" placeholder="Password" name="pwd"/><br><br><br>
                <input type="submit" name="login" value="Login"/>
            </div>
			</form>

			</body>