<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	
	<style>
body {
  font-family: "Lato", sans-serif;
}

.main2 {
 margin-left: 400px; /* Same width as the sidebar + left position in px */
   margin-right: 400px;
   margin-top:100px;
  
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 40px 40px 10px 40px;
 
}
.main2 font{
	font-family: 'Acme', sans-serif;
}

.main {
 margin-left: 230px; /* Same width as the sidebar + left position in px */
   margin-right: 150px;
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 40px 40px 40px 40px;
  
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
	 table iframe{
		 padding:100px;
	 }
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
  
  .classSubmit{
	  padding:8px 8px 8px 8px;
	  color: #ffffff;
	  background: #CD5C5C;
	  
  }
</style>

</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="d_cash.php">Cash Donation</a></li>
								<li><a href="d_goods_donation.php">Goods Donation</a></li>
								<li><a href="d_ngosearch.php">NGO Search</a></li>
								<li><a href="d_profile.php">Profile</a></li>
								<li><a href="donor-login.php">Log Out</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		
	?>
	


	
	<div class="main2">
	<form method="post" action="d_ngo_validate.php"><center>
	<h2><font color="#CD5C5C"><u>NGO SEARCH</u></font></h2><br>
		<h2>Enter NGO full name:
		<input type="text" style="background:#D0D0D0" name="ngo" required/><br><br>
		<input type="submit" class="classSubmit" name="search" value="Search"/></h2>
	</form><br><br></center><center>
	</div>
	
	<div class="main">
	<table>
		<th>NGO details</th>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		//$s=var_dump($db);
		$ngo=$_REQUEST["ngo"];
		$q="select * from ngo_login where name='$ngo';";
		$result = $conn->query($q);
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>NGO name</td><td>".$row["name"]."</td></tr>".
						"<tr><td>NGO Email</td><td>".$row["email"]."</td></tr>".
						"<tr><td>Address</td><td>".$row["address"]."</td></tr>".
						"<tr><td>Phone Number</td><td>".$row["phone_no"]."</td></tr>".
						"<tr><td>City</td><td>".$row["city"]."</td></tr>".
						"<tr><td>State</td><td>".$row["state"]."</td></tr>";
						echo "</table><br><br>";
			if($ngo=="yatna ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.725797990161!2d78.41947041482656!3d17.424941888056125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb972b3819db73%3A0xa52c8a9c201a4e89!2sYatna+NGO!5e0!3m2!1sen!2sin!4v1563715035322!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			else if($ngo=="abhaya foundation"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.002928906712!2d78.45416041482632!3d17.411647088064058!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99bc7ed70b31%3A0x987577ba7eb192d0!2sAbhaya+Foundation!5e0!3m2!1sen!2sin!4v1563715267680!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			else if($ngo=="shine ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60925.039589445885!2d78.51289745539181!3d17.372634069073438!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9f4d0e395087%3A0x1b725318e7002025!2sShine+Ngo!5e0!3m2!1sen!2sin!4v1563715993909!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			else if($ngo=="share a smile ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15228.648793638382!2d78.47485856977538!3d17.40400200000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99dd82f5c7f1%3A0xfe1a295da517b505!2sShare+A+Smile+NGO!5e0!3m2!1sen!2sin!4v1563765387413!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			else if($ngo=="suvidha ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15226.940133275857!2d78.44223796977536!3d17.424499!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb973540000001%3A0xd8b9cdcc240a6e8!2sSuvidha+Ngo!5e0!3m2!1sen!2sin!4v1563776545140!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></center>';
			}
			else if($ngo=="ashray akruti"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.6276541038537!2d78.43894815066672!3d17.429647787994725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90cd8a911ff5%3A0x6cc6345b83946fa4!2sAshray%20Akruti!5e0!3m2!1sen!2sin!4v1567161901010!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="desire ngo"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d243649.03161513235!2d78.26390253571952!3d17.41101407519961!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb8c551918a48b%3A0xacc8f7f8fc47aa79!2sDESIRE%20Society!5e0!3m2!1sen!2sin!4v1567162349736!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="sannihitha center"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.390460775399!2d78.45963965066692!3d17.44101588798792!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90bae2f0371f%3A0x90c3c1af7e969812!2sSannihita%20center!5e0!3m2!1sen!2sin!4v1567162639731!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="NGOS GROUP"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.4429612204676!2d78.4386172506669!3d17.438500287989374!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90daca0d9dd3%3A0x6d58e021214b996!2sNGOS%20GROUP!5e0!3m2!1sen!2sin!4v1567163137430!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="youngistaan foundation"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.0516684696217!2d78.43607425066651!3d17.409307888006953!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb99d60ab4e851%3A0x92663accb9256558!2sYoungistaan%20Foundation!5e0!3m2!1sen!2sin!4v1567163798501!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="nirmaan organization"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60912.82772298087!2d78.40315221398697!3d17.409304805799174!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb92f255555557%3A0x75534ec8cd28194e!2sNirmaan%20Organization%20-%20Central%20Office!5e0!3m2!1sen!2sin!4v1567164076378!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="youth for seva"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60894.39609420003!2d78.40153564309067!3d17.464511421166733!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb915c30144df1%3A0x1a7a80a00807462f!2sYouth%20For%20Seva!5e0!3m2!1sen!2sin!4v1567180934233!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="swayam krishi sangam"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.82972213064!2d78.42907145066665!3d17.419957488000524!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb972a3db997a5%3A0x68d9a8946baf2abb!2sSwayam%20Krishi%20Sangam!5e0!3m2!1sen!2sin!4v1567181656753!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="swecha office" || $ngo=="Swecha Office"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.496956646212!2d78.35821735066682!3d17.435912687990918!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb93933cbda09f%3A0xa0c03250867be025!2sSwecha%20Office!5e0!3m2!1sen!2sin!4v1567182203762!5m2!1sen!2sin" width="1300" height="40
			0" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo=="sphoorti foundation" || $ngo="Sphoorti Foundation"){
			echo '<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3802.8556965329612!2d78.43533995066909!3d17.609585987886682!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb8f2c9bebdf45%3A0x4dc1b2ec4ec1ddee!2sSphoorti%20Foundation!5e0!3m2!1sen!2sin!4v1567182639905!5m2!1sen!2sin" width="1300" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe></center>';
			}
			else if($ngo==""){
			echo '<center></center>';
			}
			else if($ngo==""){
			echo '<center></center>';
			}
			else if($ngo==""){
			echo '<center></center>';
			}
			else if($ngo==""){
			echo '<center></center>';
			}
			else{
				echo "<tr><td>No NGO available with this name</td></tr>";
			}}}
		
	?>
	<br><br><br>
	</div>
</body>
</html>