<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
</head>

<body>

	<!-- header -->
	<header>
		<div id="search-bar">
			<div class="container">
				<div class="row">
					<form action="#" name="search" class="col-xs-12">
						<input type="text" name="search" placeholder="Type and Hit Enter"><i id="search-close" class="fa fa-close"></i>
					</form>
				</div>
			</div>
		</div>
		<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
									<li><a href="about-us.php">About Us</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
							<li>
								<a href="#">Admin</a>
							</li>
							<li>
								<a href="donor-login.php">Donor</a>
							</li>
							<li>
								<a href="ngo.php">NGO</a>
							</li>
						</ul>
					</div>
					
				</div>
			</div>	
		</nav>
	</header>


	<br><br><br><br>
	<!-- about wrapper -->
	<div class="about-page-wrapper">
		<div class="description container">
			<div class="row ">
				<div class="col-md-6 ">
					<div class="image-wrapper">
						<img class="img-responsive" src="about-us.png" alt="">
					</div>
				</div>
				<div class="col-md-6 ">
					<div class="about-right-text">
						<div class="widget-title">
							<h4>Hi... We Provide Charity Service</h4>
						</div>
						<p class="first">We provide bridging website between donors and NGOS's. Many times, NGO's will not be aware of donors and vice versa. So, we provide a solution for that. By matching the requirements of the NGO and the donor items, we provide information</p>
								
					</div>
				</div>
			</div>
		</div>
		
		<br><br><br><br><br><br><br><br><br><br><br><br>
	

	<!-- Scripts -->
	<script type="text/javascript" src="assets/js/jquery2.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.meanmenu.js"></script>
	<script type="text/javascript" src="assets/js/progress-bar-appear.js"></script>
	<script type="text/javascript" src="assets/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
	<script type="text/javascript" src="assets/js/isotope.min.js"></script>
	<script type="text/javascript" src="assets/js/countdown.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBEypW1XtGLWpikFPcityAok8rhJzzWRw "></script>
	<script type="text/javascript" src="assets/js/gmaps.js"></script>
	<script type="text/javascript" src="assets/js/plugins.js"></script>
	<script type="text/javascript" src="assets/js/js.js"></script>

</body>
</html>