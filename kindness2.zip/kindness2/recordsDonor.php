<?php
    session_start();
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	?>
<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}

.main {
  margin-left: 150px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								
								<li><a href="recordsNGO.php">NGO Records</a></li>
								<li><a href="recordsDonor.php">Donor Records</a></li>
								<li><a href="sendMails.php">Send emails</a></li>
								<li><a href="feedback.php">Feedback</a></li>
								<li><a href="admin_login.php">LogOut</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$q=mysqli_query($conn,"select * from donor_user;");
		while($row1=$q->fetch_assoc()){
			$email=$row1["d_email"];
			$sqlt = "SELECT ngo,items from donor_donations where d_email='$email';";
			$result = mysqli_query($conn,$sqlt);
			if (mysqli_num_rows($result) > 0) {
				echo "<table><th>NGO</th><th>Items</th><th>Cash</th>";
				while($row = $result->fetch_assoc()) {
					$n=$row["ngo"];
					$s=mysqli_query($conn,"select * from cash_records where d_email='$email' and ngo='$n'");
					if(mysqli_num_rows($s)==0){
						$casher=0;
					}
					else{
						$c=mysqli_fetch_array($s,MYSQLI_BOTH);
						$casher=$c["cash"];
					}
					echo "<tr><td>".$row["ngo"]."</td><td>".$row["items"]."</td><td>".$casher."</td></tr>";
			}
			$d=mysqli_query($conn,"select * from cash_records where d_email='$email'");
			while($row2 = $d->fetch_assoc()) {
				$ngo2=$row2["ngo"];
				if(mysqli_num_rows(mysqli_query($conn,"select * from donor_donations where ngo='$ngo2'"))==0){
					echo "<tr><td>".$ngo2."</td><td>--</td><td>".$row2["cash"]."</td></tr>";
				}
			}
			
			echo "</table>";
			}
			else
				echo "No donation details\n";
		}
		
	?>